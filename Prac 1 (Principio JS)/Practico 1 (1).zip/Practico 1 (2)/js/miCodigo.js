inicializar();

function inicializar() {
    document.querySelector("#btnE1").addEventListener("click", solucionEjercicio1);
    document.querySelector("#btnAcumularE15").addEventListener("click", acumularEjercicio15);
    document.querySelector("#btnResultadoE15").addEventListener("click", resultadoEjercicio15);
}

function solucionEjercicio1() {
    let nombre = document.querySelector("#txtNombreE1").value;
    let apellido = document.querySelector("#txtApellidoE1").value;

    let resultado = apellido + ", " + nombre;

    document.querySelector("#divResultadoE1").innerHTML = resultado;
}

let acumuladorEjercicio15 = 0;

function acumularEjercicio15() {
    let numeroIngresado = document.querySelector("#txtNumeroE15").value;
    let numeroIngresadoNumerico = parseInt(numeroIngresado);
 
    // acumuladorEjercicio15 = acumuladorEjercicio15 + numeroIngresadoNumerico;
    acumuladorEjercicio15 += numeroIngresadoNumerico;
}

function resultadoEjercicio15() {
    let resultado = "El total acumulado es: " + acumuladorEjercicio15;
    document.querySelector("#divResultadoE15").innerHTML = resultado;
}
